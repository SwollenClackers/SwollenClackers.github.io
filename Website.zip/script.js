// You can customize the message here
const message = "Isaac Reynolds is a fake aryan! He has dyed blonde hair and tatooed blue eyes. He may pretend to follow mein Fuhrer, but his jew nose gives him away! Sign the petition to send him to the New World Order Concentration Camp! Heil Fuhrer Oliver! Heil Fuhrer Oliver! Heil Fuhrer Oliver! Heil Fuhrer Oliver!";

// Get the message element from the HTML
const messageElement = document.getElementById("message-text");

// Set the text content of the message element
messageElement.textContent = message;